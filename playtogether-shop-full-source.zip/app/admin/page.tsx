"use client";
import { useEffect,useState } from "react";
import Link from "next/link";
import { supabase } from "../../lib/supabase";

type Deposit={id:number;user_id:string;amount:number;transfer_code:string;status:string;created_at:string};
type Order={id:number;total:number;status:string;created_at:string;game_id:string;contact:string};

export default function Admin(){
 const [allowed,setAllowed]=useState(false),[deposits,setDeposits]=useState<Deposit[]>([]),[orders,setOrders]=useState<Order[]>([]),[msg,setMsg]=useState("");
 async function load(){
  if(!supabase)return;
  const {data:{user}}=await supabase.auth.getUser(); if(!user)return;
  const p=await supabase.from("profiles").select("role").eq("id",user.id).single();
  if(p.data?.role!=="admin"){setMsg("Bạn không có quyền Admin.");return}
  setAllowed(true);
  const d=await supabase.from("deposits").select("*").order("created_at",{ascending:false}).limit(50);
  const o=await supabase.from("orders").select("*").order("created_at",{ascending:false}).limit(50);
  setDeposits(d.data||[]);setOrders(o.data||[]);
 }
 useEffect(()=>{load()},[]);
 async function approve(d:Deposit,ok:boolean){
  if(!supabase)return;
  // Production note: balance changes should be performed through a trusted RPC/server route
  // that atomically updates balance + transaction + deposit status.
  const {error}=await supabase.from("deposits").update({status:ok?"approved":"rejected",reviewed_at:new Date().toISOString()}).eq("id",d.id);
  setMsg(error?error.message:"Đã cập nhật trạng thái nạp tiền.");
  load();
 }
 async function orderStatus(id:number,status:string){
  if(!supabase)return;
  const {error}=await supabase.from("orders").update({status,updated_at:new Date().toISOString()}).eq("id",id);
  setMsg(error?error.message:"Đã cập nhật đơn.");load();
 }
 if(msg&&!allowed)return <main className="auth"><div className="authCard"><Link href="/">← Trang chủ</Link><h1>{msg}</h1></div></main>;
 return <main className="dashboard"><header className="dashNav"><Link href="/">PTSHOP ADMIN</Link><Link href="/dashboard">Tài khoản</Link></header>
 <section className="panel"><h2>Nạp tiền chờ duyệt</h2>{deposits.map(d=><div className="row" key={d.id}><b>#{d.id}</b><span>{d.amount.toLocaleString("vi-VN")}đ</span><span>{d.transfer_code}</span><span>{d.status}</span>{d.status==="pending"&&<><button onClick={()=>approve(d,true)}>Duyệt</button><button onClick={()=>approve(d,false)}>Từ chối</button></>}</div>)}</section>
 <section className="panel"><h2>Quản lý đơn</h2>{orders.map(o=><div className="row" key={o.id}><b>#{o.id}</b><span>{o.total.toLocaleString("vi-VN")}đ</span><span>{o.status}</span><select value={o.status} onChange={e=>orderStatus(o.id,e.target.value)}><option>pending</option><option>processing</option><option>doing</option><option>completed</option><option>cancelled</option></select></div>)}</section>
 {msg&&<p>{msg}</p>}</main>
}