"use client";
import { FormEvent,useState } from "react";
import Link from "next/link";
import { supabase } from "../../lib/supabase";

export default function Deposit(){
 const [amount,setAmount]=useState(""); const [code,setCode]=useState(""); const [msg,setMsg]=useState("");
 async function submit(e:FormEvent){e.preventDefault();setMsg("");
  if(!supabase){setMsg("Chưa cấu hình Supabase.");return}
  const {data:{user}}=await supabase.auth.getUser(); if(!user){setMsg("Hãy đăng nhập.");return}
  const {error}=await supabase.from("deposits").insert({user_id:user.id,amount:Number(amount),transfer_code:code});
  setMsg(error?error.message:"Đã gửi yêu cầu nạp tiền, chờ Admin duyệt.");
 }
 return <main className="auth"><form className="authCard" onSubmit={submit}><Link href="/dashboard" className="back">← Tài khoản</Link><h1>Nạp tiền</h1><p>Chuyển khoản theo thông tin shop cung cấp, sau đó gửi mã giao dịch.</p><input type="number" min="1000" placeholder="Số tiền" value={amount} onChange={e=>setAmount(e.target.value)} required/><input placeholder="Mã giao dịch / nội dung chuyển khoản" value={code} onChange={e=>setCode(e.target.value)} required/><button className="btn primary">GỬI YÊU CẦU</button>{msg&&<small>{msg}</small>}</form></main>
}