"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabase";

type Order={id:number;total:number;status:string;created_at:string;services?:{name:string}|null};

export default function Dashboard(){
  const [email,setEmail]=useState(""); const [balance,setBalance]=useState(0); const [orders,setOrders]=useState<Order[]>([]);
  useEffect(()=>{(async()=>{
    if(!supabase)return;
    const {data:{user}}=await supabase.auth.getUser();
    if(!user)return;
    setEmail(user.email||"");
    const p=await supabase.from("profiles").select("balance").eq("id",user.id).single();
    setBalance(p.data?.balance||0);
    const o=await supabase.from("orders").select("id,total,status,created_at,services(name)").eq("user_id",user.id).order("created_at",{ascending:false}).limit(20);
    setOrders((o.data||[]) as Order[]);
  })()},[]);
  return <main className="dashboard"><header className="dashNav"><Link href="/">PTSHOP</Link><span>{email}</span><Link href="/deposit">Nạp tiền</Link></header>
    <section className="dashGrid">
      <div className="stat"><small>SỐ DƯ</small><strong>{balance.toLocaleString("vi-VN")}đ</strong></div>
      <div className="stat"><small>ĐƠN HÀNG</small><strong>{orders.length}</strong></div>
    </section>
    <section className="panel"><h2>Lịch sử đơn hàng</h2>{orders.length===0?<p>Chưa có đơn.</p>:orders.map(o=><div className="row" key={o.id}><b>#{o.id}</b><span>{o.services?.name||"Dịch vụ"}</span><span>{o.total.toLocaleString("vi-VN")}đ</span><span>{o.status}</span></div>)}</section>
  </main>
}