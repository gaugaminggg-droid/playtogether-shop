 "use client";
import { FormEvent, useSearchParams } from "next/navigation";
import { useState } from "react";
import Link from "next/link";

export default function OrderPage() {
  const params = useSearchParams();
  const service = params.get("service") || "";
  const [sent, setSent] = useState(false);

  function submit(e: FormEvent) {
    e.preventDefault();
    setSent(true);
  }

  return (
    <main className="auth">
      <form className="authCard wide" onSubmit={submit}>
        <Link href="/" className="back">← Quay lại</Link>
        <h1>Đặt dịch vụ</h1>
        <p>Điền thông tin để shop tiếp nhận đơn.</p>
        <label>Dịch vụ</label>
        <input value={service} readOnly />
        <label>ID Play Together</label>
        <input placeholder="Nhập ID" required />
        <label>Tên nhân vật</label>
        <input placeholder="Nhập tên nhân vật" required />
        <label>Liên hệ</label>
        <input placeholder="Zalo / Facebook" required />
        <label>Ghi chú</label>
        <textarea placeholder="Yêu cầu thêm..." rows={4} />
        <button className="btn primary" type="submit">GỬI ĐƠN</button>
        {sent && <div className="success">Đã ghi nhận yêu cầu. Shop sẽ liên hệ qua thông tin bạn cung cấp.</div>}
      </form>
    </main>
  );
}