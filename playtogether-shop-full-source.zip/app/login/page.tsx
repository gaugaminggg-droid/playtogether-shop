 "use client";
import { FormEvent, useState } from "react";
import Link from "next/link";
import { supabase } from "../../lib/supabase";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!supabase) {
      setMsg("Chưa cấu hình Supabase. Hãy điền .env.local.");
      return;
    }
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setMsg(error ? error.message : "Đăng nhập thành công.");
  }

  return (
    <main className="auth">
      <form className="authCard" onSubmit={submit}>
        <Link href="/" className="back">← Trang chủ</Link>
        <h1>Đăng nhập</h1>
        <p>Quản lý đơn hàng và tài khoản của bạn.</p>
        <input placeholder="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
        <input placeholder="Mật khẩu" type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
        <button className="btn primary" type="submit">ĐĂNG NHẬP</button>
        {msg && <small>{msg}</small>}
      </form>
    </main>
  );
}